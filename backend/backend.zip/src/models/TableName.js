module.exports = Object.freeze({
    TBL_USER:'tbl_user',
    TBL_BLOG:'tbl_blog',
    TBL_CATEGORY:'tbl_category',
    TBL_CAREER:'tbl_career',
    TBL_LATESTUPDATE:'tbl_latestupdate',
    TBl_CONTACT:'tbl_contact',
});